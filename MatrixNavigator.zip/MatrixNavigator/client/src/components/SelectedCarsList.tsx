import { Car } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartScatter, Plus, Trash2 } from "lucide-react";

interface SelectedCarsListProps {
  selectedCars: Car[];
  onRemove: (id: number) => void;
  onAnalyze: () => void;
}

const SelectedCarsList = ({ selectedCars, onRemove, onAnalyze }: SelectedCarsListProps) => {
  const maxCars = 5;

  return (
    <Card className="mb-8">
      <CardHeader className="pb-3">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
          <div>
            <CardTitle className="text-lg font-heading font-semibold text-gray-700">
              Xe đã chọn để phân tích ({selectedCars.length}/{maxCars})
            </CardTitle>
            <CardDescription className="text-sm text-gray-500 mt-1">
              Chọn tối thiểu 2 xe và tối đa 5 xe để tiến hành phân tích
            </CardDescription>
          </div>
          <Button
            onClick={onAnalyze}
            disabled={selectedCars.length < 2}
            className="mt-3 sm:mt-0"
          >
            <ChartScatter className="w-4 h-4 mr-2" />
            Phân tích AHP
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {selectedCars.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {selectedCars.map(car => (
              <div key={car.id} className="bg-gray-50 rounded-lg p-3 border border-gray-100">
                <div className="flex items-center mb-2">
                  <img 
                    src={car.imageUrl} 
                    alt={`${car.brand} ${car.name}`} 
                    className="w-16 h-10 object-cover rounded mr-2" 
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-sm truncate">{car.brand} {car.name}</h3>
                    <p className="text-xs text-gray-600 truncate">{car.model}</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-red-500 hover:text-red-600 hover:bg-red-50 text-xs flex items-center w-full justify-center"
                  onClick={() => onRemove(car.id)}
                >
                  <Trash2 className="w-3 h-3 mr-1" />
                  Loại bỏ
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-6 border-2 border-dashed border-gray-300 rounded-lg text-center flex-grow">
            <Plus className="mx-auto h-8 w-8 text-gray-400 mb-2" />
            <p className="text-gray-500">Bạn chưa chọn xe nào</p>
            <p className="text-sm text-gray-400 mt-1">Chọn các xe từ danh sách bên dưới để so sánh</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SelectedCarsList;
