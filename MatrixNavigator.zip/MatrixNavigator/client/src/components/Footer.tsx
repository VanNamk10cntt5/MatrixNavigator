import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Facebook, Mail, Phone, Send } from "lucide-react";

const Footer = () => {
  const { toast } = useToast();
  const [email, setEmail] = useState("");

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      toast({
        title: "Lỗi đăng ký",
        description: "Vui lòng nhập địa chỉ email hợp lệ",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Đăng ký thành công",
      description: "Cảm ơn bạn đã đăng ký nhận thông tin mới nhất từ AutoAHP"
    });
    setEmail("");
  };

  return (
    <footer className="bg-gray-700 text-gray-200 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-heading font-semibold mb-4">Về AutoAHP</h3>
            <p className="text-sm text-gray-400 mb-4">
              Hệ thống hỗ trợ ra quyết định khách quan giúp bạn lựa chọn ô tô phù hợp nhất 
              với nhu cầu dựa trên phương pháp phân tích thứ bậc (AHP).
            </p>
            <div className="flex items-center space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition duration-150">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-150">
                <Mail size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-150">
                <Phone size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-heading font-semibold mb-4">Liên kết nhanh</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="/" className="text-gray-400 hover:text-white transition duration-150">
                  Trang chủ
                </a>
              </li>
              <li>
                <a href="/analysis" className="text-gray-400 hover:text-white transition duration-150">
                  Tìm hiểu phương pháp AHP
                </a>
              </li>
              <li>
                <a href="/" className="text-gray-400 hover:text-white transition duration-150">
                  Thông tin các loại xe
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition duration-150">
                  Tin tức thị trường ô tô
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition duration-150">
                  Liên hệ
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-heading font-semibold mb-4">Đăng ký nhận tin</h3>
            <p className="text-sm text-gray-400 mb-4">Nhận thông tin mới nhất về thị trường ô tô Việt Nam</p>
            <form className="flex" onSubmit={handleSubscribe}>
              <Input
                type="email"
                placeholder="Email của bạn"
                className="rounded-l-md py-2 px-3 text-sm w-full focus:outline-none text-gray-700 border-r-0"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <Button 
                type="submit" 
                className="bg-primary hover:bg-primary-dark text-white rounded-r-md px-4 transition duration-150 ease-in-out"
              >
                <Send size={16} />
              </Button>
            </form>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-600 text-center text-sm text-gray-400">
          <p>&copy; 2023 AutoAHP - Hệ thống hỗ trợ ra quyết định mua ô tô. Bản quyền thuộc về HCMUTE.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
