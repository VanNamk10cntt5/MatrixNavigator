import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { HelpCircle, Car } from "lucide-react";
import { 
  Sheet, 
  SheetContent, 
  SheetDescription, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger
} from "@/components/ui/sheet";

const Navbar = () => {
  const [location, setLocation] = useLocation();

  const isActive = (path: string) => location === path;

  const handleNavigation = (path: string) => {
    setLocation(path);
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center cursor-pointer" onClick={() => handleNavigation("/")}>
            <span className="material-icons text-primary mr-2 text-2xl">directions_car</span>
            <div className="flex flex-col">
              <span className="text-xl font-heading font-bold text-primary">HỆ THỐNG QUYẾT ĐỊNH</span>
              <span className="text-sm text-muted-foreground">Lựa chọn ô tô bằng phương pháp AHP</span>
            </div>
          </div>
          
          <div className="flex items-center">
            <div className="hidden md:block">
              <div className="flex items-baseline space-x-4">
                <Button 
                  variant={isActive("/") ? "default" : "ghost"} 
                  onClick={() => handleNavigation("/")}
                  className="text-sm font-medium transition-all"
                >
                  <Car className="h-4 w-4 mr-2" />
                  Chọn Xe
                </Button>
                
                <Button 
                  variant={isActive("/analysis") ? "default" : "ghost"} 
                  onClick={() => handleNavigation("/analysis")}
                  className="text-sm font-medium transition-all"
                >
                  <span className="material-icons text-sm mr-2">analytics</span>
                  Phân Tích AHP
                </Button>
              </div>
            </div>
          </div>
          
          <div className="flex items-center">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="secondary" className="text-secondary-foreground hover:opacity-90">
                  <HelpCircle className="h-4 w-4 mr-2" />
                  Hướng dẫn
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle className="text-primary text-xl">Hướng dẫn sử dụng</SheetTitle>
                  <SheetDescription className="text-base">
                    Phương pháp AHP (Phân tích thứ bậc) cho lựa chọn ô tô
                  </SheetDescription>
                </SheetHeader>
                <div className="py-4">
                  <h3 className="font-semibold text-lg mb-2 text-primary">Các bước thực hiện</h3>
                  <ol className="list-decimal pl-5 space-y-2">
                    <li>Chọn từ 2-5 xe bạn muốn so sánh từ danh sách</li>
                    <li>Chuyển đến trang Phân tích AHP</li>
                    <li>Nhập ma trận so sánh cặp giữa các tiêu chí (1-9)</li>
                    <li>Nhập ma trận so sánh cặp giữa các xe theo từng tiêu chí</li>
                    <li>Xem kết quả và xuất báo cáo PDF nếu cần</li>
                  </ol>
                  
                  <h3 className="font-semibold text-lg mt-6 mb-2 text-primary">Thang điểm AHP</h3>
                  <div className="bg-accent p-3 rounded-lg">
                    <ul className="space-y-1 text-sm">
                      <li><strong>1:</strong> Hai yếu tố quan trọng như nhau</li>
                      <li><strong>3:</strong> Yếu tố này hơi quan trọng hơn</li>
                      <li><strong>5:</strong> Yếu tố này khá quan trọng hơn</li>
                      <li><strong>7:</strong> Yếu tố này rất quan trọng hơn</li>
                      <li><strong>9:</strong> Yếu tố này cực kỳ quan trọng hơn</li>
                      <li>2, 4, 6, 8: Các giá trị trung gian</li>
                    </ul>
                  </div>
                  
                  <h3 className="font-semibold text-lg mt-6 mb-2 text-primary">Về chỉ số nhất quán (CR)</h3>
                  <div className="bg-accent p-3 rounded-lg">
                    <p className="text-sm">
                      Chỉ số CR dưới 0.1 được coi là chấp nhận được, thể hiện sự nhất quán trong đánh giá của bạn.
                      Nếu CR {'>'} 0.1, bạn nên xem xét lại các đánh giá.
                    </p>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
      
      <div className="md:hidden border-t">
        <div className="flex justify-center space-x-1 px-2 pt-2 pb-3 sm:px-3">
          <Button 
            variant={isActive("/") ? "default" : "outline"} 
            onClick={() => handleNavigation("/")}
            className="text-sm font-medium flex-1 justify-center"
          >
            <Car className="h-4 w-4 mr-2" />
            Chọn Xe
          </Button>
          
          <Button 
            variant={isActive("/analysis") ? "default" : "outline"} 
            onClick={() => handleNavigation("/analysis")}
            className="text-sm font-medium flex-1 justify-center"
          >
            <span className="material-icons text-sm mr-2">analytics</span>
            Phân Tích AHP
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
