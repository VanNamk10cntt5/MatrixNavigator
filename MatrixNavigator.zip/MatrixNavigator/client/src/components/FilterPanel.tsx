import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";
import { RefreshCw, Sparkles, Filter, Tag, Zap } from "lucide-react";
import { carCategories } from "@shared/schema";
import { formatPrice } from "@/lib/utils";

interface FilterPanelProps {
  filters: {
    category: string;
    priceMax: number;
    brand: string;
    horsepowerMin: number;
    fuelConsumptionMax: number;
    sort: string;
  };
  onFilterChange: (filters: any) => void;
  onReset: () => void;
}

const FilterPanel = ({ filters, onFilterChange, onReset }: FilterPanelProps) => {
  const [priceDisplay, setPriceDisplay] = useState(filters.priceMax);
  const [horsepowerDisplay, setHorsepowerDisplay] = useState(filters.horsepowerMin);
  const [fuelDisplay, setFuelDisplay] = useState(filters.fuelConsumptionMax);
  
  useEffect(() => {
    setPriceDisplay(filters.priceMax);
    setHorsepowerDisplay(filters.horsepowerMin);
    setFuelDisplay(filters.fuelConsumptionMax);
  }, [filters]);

  const handlePriceChange = (value: number[]) => {
    setPriceDisplay(value[0]);
  };

  const handlePriceChangeCommitted = (value: number[]) => {
    onFilterChange({ priceMax: value[0] });
  };

  const handleHorsepowerChange = (value: number[]) => {
    setHorsepowerDisplay(value[0]);
  };

  const handleHorsepowerChangeCommitted = (value: number[]) => {
    onFilterChange({ horsepowerMin: value[0] });
  };

  const handleFuelChange = (value: number[]) => {
    setFuelDisplay(value[0]);
  };

  const handleFuelChangeCommitted = (value: number[]) => {
    onFilterChange({ fuelConsumptionMax: value[0] });
  };

  const brands = [
    "Toyota",
    "Honda",
    "Ford",
    "Hyundai",
    "KIA",
    "Mazda",
    "VinFast",
    "Mercedes-Benz",
    "BMW",
    "Audi"
  ];

  // Các gợi ý cho từng nhu cầu
  const suggestions = [
    {
      name: "Xe gia đình",
      description: "Phù hợp cho gia đình 4-5 người",
      filters: {
        category: "SUV", 
        priceMax: 1500, 
        horsepowerMin: 150,
        fuelConsumptionMax: 8
      },
      icon: <Tag className="h-4 w-4" />
    },
    {
      name: "Tiết kiệm nhiên liệu",
      description: "Xe tiết kiệm nhiên liệu nhất",
      filters: {
        category: "Hatchback", 
        priceMax: 1000, 
        horsepowerMin: 100,
        fuelConsumptionMax: 5.5,
        sort: "fuel-asc"
      },
      icon: <Filter className="h-4 w-4" />
    },
    {
      name: "Hiệu suất cao",
      description: "Cho người yêu thích trải nghiệm lái",
      filters: {
        category: "Sedan", 
        priceMax: 2000, 
        horsepowerMin: 200,
        sort: "power-desc"
      },
      icon: <Zap className="h-4 w-4" />
    }
  ];

  const handleApplySuggestion = (suggestionFilters: any) => {
    onFilterChange(suggestionFilters);
  };

  return (
    <Card className="mb-8">
      <CardHeader className="pb-3">
        <div className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg font-heading font-semibold text-gray-700">
            Bộ lọc nâng cao
          </CardTitle>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onReset}
            className="text-gray-700 flex items-center"
          >
            <RefreshCw className="w-4 h-4 mr-1" />
            Đặt lại
          </Button>
        </div>
        <CardDescription className="mt-2">
          Tùy chỉnh bộ lọc để tìm xe phù hợp với nhu cầu của bạn
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Gợi ý nhanh */}
        <div className="mb-4">
          <div className="flex items-center mb-2">
            <Sparkles className="h-4 w-4 text-secondary mr-2" />
            <Label className="font-medium">Gợi ý nhanh</Label>
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((suggestion, index) => (
              <Button
                key={index}
                variant="outline"
                className="flex items-center gap-1 h-auto py-1 px-3 border-dashed"
                onClick={() => handleApplySuggestion(suggestion.filters)}
              >
                {suggestion.icon}
                <div className="flex flex-col items-start">
                  <span className="text-sm">{suggestion.name}</span>
                  <span className="text-xs text-muted-foreground">{suggestion.description}</span>
                </div>
              </Button>
            ))}
          </div>
        </div>

        {/* Bộ lọc chính */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="flex flex-col">
            <Label className="text-sm font-medium text-gray-600 mb-1">Loại xe</Label>
            <Select
              value={filters.category}
              onValueChange={(value) => onFilterChange({ category: value })}
            >
              <SelectTrigger className="bg-gray-100 border border-gray-300">
                <SelectValue placeholder="Tất cả" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả</SelectItem>
                {carCategories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-col">
            <Label className="text-sm font-medium text-gray-600 mb-1">
              Tầm giá (Triệu VNĐ)
            </Label>
            <div className="flex items-center space-x-2 pt-2">
              <Slider
                defaultValue={[filters.priceMax]}
                max={5000}
                min={500}
                step={100}
                value={[priceDisplay]}
                onValueChange={handlePriceChange}
                onValueCommit={handlePriceChangeCommitted}
                className="flex-grow h-2"
              />
              <span className="text-gray-600 text-sm min-w-[80px]">
                ≤ {formatPrice(priceDisplay)}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col">
            <Label className="text-sm font-medium text-gray-600 mb-1">Thương hiệu</Label>
            <Select
              value={filters.brand}
              onValueChange={(value) => onFilterChange({ brand: value })}
            >
              <SelectTrigger className="bg-gray-100 border border-gray-300">
                <SelectValue placeholder="Tất cả" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all_brands">Tất cả</SelectItem>
                {brands.map(brand => (
                  <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-col">
            <Label className="text-sm font-medium text-gray-600 mb-1">
              Công suất (HP)
            </Label>
            <div className="flex items-center space-x-2 pt-2">
              <Slider
                defaultValue={[filters.horsepowerMin]}
                max={500}
                min={100}
                step={10}
                value={[horsepowerDisplay]}
                onValueChange={handleHorsepowerChange}
                onValueCommit={handleHorsepowerChangeCommitted}
                className="flex-grow h-2"
              />
              <span className="text-gray-600 text-sm min-w-[80px]">
                ≥ {horsepowerDisplay}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col">
            <Label className="text-sm font-medium text-gray-600 mb-1">
              Mức tiêu hao (L/100km)
            </Label>
            <div className="flex items-center space-x-2 pt-2">
              <Slider
                defaultValue={[filters.fuelConsumptionMax]}
                max={15}
                min={4}
                step={0.5}
                value={[fuelDisplay]}
                onValueChange={handleFuelChange}
                onValueCommit={handleFuelChangeCommitted}
                className="flex-grow h-2"
              />
              <span className="text-gray-600 text-sm min-w-[80px]">
                ≤ {fuelDisplay.toFixed(1)}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col">
            <Label className="text-sm font-medium text-gray-600 mb-1">Sắp xếp theo</Label>
            <Select
              value={filters.sort}
              onValueChange={(value) => onFilterChange({ sort: value })}
            >
              <SelectTrigger className="bg-gray-100 border border-gray-300">
                <SelectValue placeholder="Sắp xếp theo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="price-asc">Giá: Thấp đến cao</SelectItem>
                <SelectItem value="price-desc">Giá: Cao đến thấp</SelectItem>
                <SelectItem value="power-desc">Công suất: Cao xuống thấp</SelectItem>
                <SelectItem value="fuel-asc">Tiêu hao nhiên liệu: Thấp đến cao</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Gợi ý và hướng dẫn */}
        <Alert className="bg-accent border-dashed border-accent-foreground/20 mt-4">
          <Sparkles className="h-4 w-4 text-secondary" />
          <AlertTitle className="text-secondary-foreground">Mẹo sử dụng</AlertTitle>
          <AlertDescription className="text-sm">
            <span className="text-muted-foreground">Chọn từ 2-5 xe để so sánh bằng phương pháp AHP. Sau đó nhấn nút </span>
            <Badge variant="outline" className="font-normal bg-primary/10 border-primary/20 text-primary">Phân tích AHP</Badge>
            <span className="text-muted-foreground"> để tiến hành phân tích chi tiết dựa trên các tiêu chí của bạn.</span>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
};

export default FilterPanel;
