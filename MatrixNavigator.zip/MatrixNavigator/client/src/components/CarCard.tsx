import { Car } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { formatPrice } from "@/lib/utils";
import { Info, Plus, Check, Shield, Gauge, Droplet, Star } from "lucide-react";

interface CarCardProps {
  car: Car;
  isSelected: boolean;
  onSelect: () => void;
  canSelect: boolean;
}

const CarCard = ({ car, isSelected, onSelect, canSelect }: CarCardProps) => {
  const handleSelect = () => {
    if (!isSelected && canSelect) {
      onSelect();
    }
  };
  
  const getCategoryClass = () => {
    const categories: Record<string, string> = {
      'Sedan': 'bg-blue-600',
      'SUV': 'bg-green-600',
      'Hatchback': 'bg-yellow-600',
      'Pickup': 'bg-red-600',
      'Crossover': 'bg-purple-600',
      'MPV': 'bg-indigo-600'
    };
    
    return categories[car.category] || 'bg-primary-dark';
  };

  return (
    <Card className="car-card overflow-hidden">
      <div className="relative">
        <img 
          src={car.imageUrl} 
          alt={`${car.brand} ${car.name}`} 
          className="w-full h-48 object-cover"
        />
        <span className={`absolute top-2 left-2 ${getCategoryClass()} text-white text-xs px-2 py-1 rounded`}>
          {car.category}
        </span>
      </div>
      
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-heading font-semibold">{car.name} {car.model}</h3>
          <span className="bg-gray-100 text-primary-dark text-xs px-2 py-1 rounded">
            {car.brand}
          </span>
        </div>
        
        <p className="font-heading font-bold text-secondary-dark text-lg mt-1">
          {formatPrice(Number(car.price))}
        </p>
        
        <div className="grid grid-cols-2 gap-x-4 gap-y-2 mt-3">
          <div className="flex items-center">
            <Gauge className="text-gray-500 w-4 h-4 mr-1" />
            <span className="text-sm text-gray-600">{car.horsepower} HP</span>
          </div>
          
          <div className="flex items-center">
            <Droplet className="text-gray-500 w-4 h-4 mr-1" />
            <span className="text-sm text-gray-600">{car.fuelConsumption} L/100km</span>
          </div>
          
          <div className="flex items-center">
            <Shield className="text-gray-500 w-4 h-4 mr-1" />
            <span className="text-sm text-gray-600">{car.airbags} túi khí</span>
          </div>
          
          <div className="flex items-center">
            <Star className="text-gray-500 w-4 h-4 mr-1" />
            <span className="text-sm text-gray-600">{car.safetyRating} sao NCAP</span>
          </div>
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="text-primary hover:text-primary-dark flex items-center">
                <Info className="w-4 h-4 mr-1" />
                Chi tiết
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{car.brand} {car.name} {car.model}</DialogTitle>
                <DialogDescription>
                  Thông tin chi tiết về xe
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="col-span-2">
                  <img 
                    src={car.imageUrl} 
                    alt={`${car.brand} ${car.name}`} 
                    className="w-full h-48 object-cover rounded-md"
                  />
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium">Hãng xe</p>
                  <p className="text-sm text-gray-500">{car.brand}</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium">Dòng xe</p>
                  <p className="text-sm text-gray-500">{car.category}</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium">Giá niêm yết</p>
                  <p className="text-sm text-gray-500">{formatPrice(Number(car.price))}</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium">Công suất</p>
                  <p className="text-sm text-gray-500">{car.horsepower} HP</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium">Tiêu thụ nhiên liệu</p>
                  <p className="text-sm text-gray-500">{car.fuelConsumption} L/100km</p>
                </div>
                
                <div className="space-y-1">
                  <p className="text-sm font-medium">Hệ thống an toàn</p>
                  <p className="text-sm text-gray-500">{car.airbags} túi khí, {car.safetyRating} sao đánh giá</p>
                </div>
                
                <div className="col-span-2 space-y-1">
                  <p className="text-sm font-medium">Tính năng</p>
                  <ul className="text-sm text-gray-500 list-disc pl-5">
                    {car.features?.map((feature, index) => (
                      <li key={index}>{feature}</li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <DialogFooter>
                {!isSelected && canSelect ? (
                  <Button onClick={onSelect}>Thêm vào so sánh</Button>
                ) : (
                  <Button disabled>
                    {isSelected ? "Đã thêm vào danh sách" : "Đã đạt giới hạn xe so sánh"}
                  </Button>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div>
                  <Button
                    className="bg-primary text-white hover:bg-primary-dark flex items-center"
                    size="sm"
                    onClick={handleSelect}
                    disabled={isSelected || !canSelect}
                  >
                    {isSelected ? (
                      <>
                        <Check className="w-4 h-4 mr-1" />
                        Đã chọn
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 mr-1" />
                        Chọn xe
                      </>
                    )}
                  </Button>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                {isSelected ? "Xe đã được chọn" : 
                 !canSelect ? "Đã đạt số lượng xe tối đa (5)" : "Thêm xe vào danh sách so sánh"}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </CardContent>
    </Card>
  );
};

export default CarCard;
