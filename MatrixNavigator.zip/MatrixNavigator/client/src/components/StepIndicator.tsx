import { StepProps } from "@/lib/types";
import { Check } from "lucide-react";

interface StepIndicatorProps {
  currentStep: number;
}

const steps: StepProps[] = [
  {
    number: 1,
    title: "So sánh tiêu chí",
    description: "Nhập ma trận so sánh cặp các tiêu chí",
  },
  {
    number: 2,
    title: "So sánh phương án",
    description: "So sánh các xe theo từng tiêu chí riêng biệt",
  },
  {
    number: 3,
    title: "Kết quả phân tích",
    description: "Xem kết quả và xuất báo cáo chi tiết",
  },
];

const StepIndicator = ({ currentStep }: StepIndicatorProps) => {
  return (
    <div className="relative mb-8">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={index} className="flex flex-col items-center relative z-10 max-w-[160px]">
            <div
              className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-medium 
                shadow-sm transition-all duration-200
                ${
                  currentStep > step.number
                    ? "bg-primary/90" 
                    : currentStep === step.number
                    ? "bg-primary ring-4 ring-primary/20"
                    : "bg-muted text-muted-foreground"
                }`}
            >
              {currentStep > step.number ? (
                <Check className="h-5 w-5" />
              ) : (
                step.number
              )}
            </div>
            <div className="mt-3 text-center">
              <span
                className={`text-sm font-medium 
                  ${
                    currentStep >= step.number 
                      ? "text-primary" 
                      : "text-muted-foreground"
                  }`}
              >
                {step.title}
              </span>
              <p className="text-xs text-muted-foreground mt-1 hidden md:block">
                {step.description}
              </p>
            </div>
            
            {/* Line connecting steps */}
            {index < steps.length - 1 && (
              <div
                className="absolute left-1/2 right-0 top-6 h-0.5 -z-10 bg-muted"
                style={{ width: "100%" }}
              >
                <div
                  className={`absolute left-0 top-0 h-full transition-all duration-300 ease-in-out
                    ${currentStep > step.number ? "bg-primary" : "bg-muted"}`}
                  style={{ width: currentStep > step.number ? "100%" : "0%" }}
                ></div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default StepIndicator;
