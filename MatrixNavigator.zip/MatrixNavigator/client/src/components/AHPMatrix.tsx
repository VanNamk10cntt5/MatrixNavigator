import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { HelpCircle, AlertTriangle, CheckCircle, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { calculateWeights, calculateConsistency } from "@/lib/ahp";
import { AHP_SCALE_DESCRIPTIONS } from "@/lib/constants";

interface AHPMatrixProps {
  matrix: number[][];
  setMatrix: (matrix: number[][]) => void;
  criteria: string[];
  hideResults?: boolean;
}

const AHPMatrix = ({ matrix, setMatrix, criteria, hideResults = false }: AHPMatrixProps) => {
  const [weights, setWeights] = useState<number[]>([]);
  const [consistency, setConsistency] = useState<{
    lambdaMax: number;
    ci: number;
    cr: number;
    isConsistent: boolean;
  }>({ lambdaMax: 0, ci: 0, cr: 0, isConsistent: true });

  // Initialize matrix if empty
  useEffect(() => {
    if (!matrix || matrix.length === 0) {
      const n = criteria.length;
      const initialMatrix = Array(n).fill(0).map((_, i) => 
        Array(n).fill(0).map((_, j) => {
          if (i === j) return 1;
          return 0;
        })
      );
      setMatrix(initialMatrix);
    } else if (matrix.length > 0) {
      // Calculate weights and consistency on matrix changes
      const calculatedWeights = calculateWeights(matrix);
      setWeights(calculatedWeights);
      
      const consistencyResults = calculateConsistency(matrix, calculatedWeights);
      setConsistency(consistencyResults);
    }
  }, [matrix, criteria.length, setMatrix]);

  const handleMatrixChange = (rowIndex: number, colIndex: number, value: number) => {
    // Validate that value is between 1 and 9
    if (value < 1 || value > 9) return;

    const newMatrix = [...matrix];
    newMatrix[rowIndex][colIndex] = value;
    
    // Update reciprocal value
    if (rowIndex !== colIndex) {
      newMatrix[colIndex][rowIndex] = +(1 / value).toFixed(3);
    }
    
    setMatrix(newMatrix);
  };

  return (
    <Card className="mb-8">
      <CardHeader className={hideResults ? "pb-2" : ""}>
        {!hideResults && (
          <>
            <CardTitle className="flex items-center gap-2">
              <span>Ma trận so sánh cặp tiêu chí</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="cursor-help">
                      <HelpCircle className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="max-w-sm">
                    <p>Nhập giá trị so sánh tầm quan trọng giữa các tiêu chí theo thang điểm từ 1-9</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </CardTitle>
            <CardDescription>
              Nhập các giá trị vào nửa trên của ma trận (các giá trị nửa dưới sẽ được tự động tính toán)
            </CardDescription>
            
            <div className="grid grid-cols-3 gap-2 mt-4 mb-2">
              {[1, 3, 5, 7, 9].map(value => (
                <div key={value} className="bg-accent p-2 rounded-md">
                  <Badge variant="outline" className="mb-1 bg-accent-foreground/5">
                    {value}
                  </Badge>
                  <p className="text-xs text-muted-foreground">
                    {AHP_SCALE_DESCRIPTIONS[value.toString()]}
                  </p>
                </div>
              ))}
            </div>
          </>
        )}
        
        {hideResults && (
          <CardTitle className="text-lg">
            So sánh {criteria.length} xe theo {criteria.length > 0 ? criteria[0] : ""}
          </CardTitle>
        )}
      </CardHeader>

      <CardContent>
        <div className="overflow-x-auto">
          <Table className="w-full border-collapse mb-6">
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="border border-border p-2 text-left font-medium min-w-[150px] bg-primary/5">
                  <div className="flex items-center gap-1">
                    <span>Tiêu chí</span>
                    {!hideResults && (
                      <Info className="h-3 w-3 text-muted-foreground" />
                    )}
                  </div>
                </TableHead>
                {criteria.map((criterion, index) => (
                  <TableHead key={index} className="border border-border p-2 text-center font-medium min-w-[100px]">
                    {criterion}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {matrix.map((row, rowIndex) => (
                <TableRow key={rowIndex} className={rowIndex % 2 === 0 ? "bg-muted/10" : ""}>
                  <TableCell className="border border-border p-2 font-medium bg-primary/5">
                    {criteria[rowIndex]}
                  </TableCell>
                  {row.map((cell, colIndex) => (
                    <TableCell 
                      key={colIndex} 
                      className={`border border-border p-1 text-center ${
                        rowIndex === colIndex ? 'bg-muted' : rowIndex > colIndex ? 'bg-muted/30' : ''
                      }`}
                    >
                      {rowIndex === colIndex ? (
                        <Badge variant="outline" className="font-normal bg-primary/5">1</Badge>
                      ) : rowIndex > colIndex ? (
                        <span className="text-xs font-mono text-muted-foreground">
                          {matrix[rowIndex][colIndex] ? (1 / matrix[colIndex][rowIndex]).toFixed(3) : ''}
                        </span>
                      ) : (
                        <Input
                          type="number"
                          min="1"
                          max="9"
                          step="1"
                          value={cell || ''}
                          onChange={(e) => handleMatrixChange(rowIndex, colIndex, Number(e.target.value))}
                          className="matrix-input w-14 h-8 text-center border rounded bg-white"
                        />
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {!hideResults && weights.length > 0 && (
          <div className="space-y-6">
            <Card className="border border-border bg-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  Kết quả tính toán 
                  <Badge variant={consistency.isConsistent ? "success" : "destructive"} className="ml-2">
                    {consistency.isConsistent ? 
                      <span className="flex items-center gap-1"><CheckCircle className="h-3 w-3" /> Nhất quán</span> : 
                      <span className="flex items-center gap-1"><AlertTriangle className="h-3 w-3" /> Không nhất quán</span>
                    }
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium mb-2 flex items-center gap-1">
                      <Info className="h-4 w-4 text-primary" />
                      Trọng số các tiêu chí
                    </h3>
                    <Table className="w-full border-collapse">
                      <TableHeader className="bg-muted/50">
                        <TableRow>
                          <TableHead className="border border-border p-2 text-left text-xs font-medium">
                            Tiêu chí
                          </TableHead>
                          <TableHead className="border border-border p-2 text-center text-xs font-medium">
                            Trọng số
                          </TableHead>
                          <TableHead className="border border-border p-2 text-center text-xs font-medium">
                            Phần trăm
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {weights.map((weight, index) => (
                          <TableRow key={index} className={index % 2 === 0 ? "bg-muted/10" : ""}>
                            <TableCell className="border border-border p-2 text-sm">
                              {criteria[index]}
                            </TableCell>
                            <TableCell className="border border-border p-2 text-center text-sm font-mono">
                              {weight.toFixed(4)}
                            </TableCell>
                            <TableCell className="border border-border p-2">
                              <div className="w-full flex items-center gap-2">
                                <Progress value={weight * 100} className="h-2" />
                                <span className="text-xs text-muted-foreground min-w-[40px] text-right">
                                  {(weight * 100).toFixed(1)}%
                                </span>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium mb-2 flex items-center gap-1">
                      <AlertTriangle className={`h-4 w-4 ${consistency.isConsistent ? 'text-green-500' : 'text-red-500'}`} />
                      Kiểm tra tính nhất quán
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-muted/20 p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Lambda max</p>
                        <p className="text-lg font-mono">
                          {consistency.lambdaMax.toFixed(3)}
                        </p>
                      </div>
                      <div className="bg-muted/20 p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Consistency Index (CI)</p>
                        <p className="text-lg font-mono">
                          {consistency.ci.toFixed(3)}
                        </p>
                      </div>
                      <div className="bg-muted/20 p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Consistency Ratio (CR)</p>
                        <p className={`text-lg font-mono ${consistency.isConsistent ? 'text-green-600' : 'text-red-600'}`}>
                          {consistency.cr.toFixed(3)}
                        </p>
                      </div>
                      <div className="bg-muted/20 p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Trạng thái</p>
                        <p className={`font-medium ${consistency.isConsistent ? 'text-green-600' : 'text-red-600'}`}>
                          {consistency.isConsistent ? 
                            <span className="flex items-center gap-1"><CheckCircle className="h-4 w-4" /> Nhất quán</span> : 
                            <span className="flex items-center gap-1"><AlertTriangle className="h-4 w-4" /> Không nhất quán</span>
                          }
                        </p>
                      </div>
                    </div>
                    <div className="mt-4 p-3 bg-accent rounded-md">
                      <p className="text-sm text-muted-foreground">
                        <strong>Lưu ý:</strong> Chỉ số CR &lt; 0.1 cho thấy ma trận so sánh có tính nhất quán chấp nhận được. Nếu CR &gt; 0.1, bạn nên xem xét lại đánh giá của mình.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AHPMatrix;
