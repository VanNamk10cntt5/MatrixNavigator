import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Car, AHPResult } from "@shared/schema";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  ArcElement,
} from 'chart.js';
import { Bar, Radar, Doughnut } from 'react-chartjs-2';
import { FileDown, Award, Check, Car as CarIcon, BarChart3 } from "lucide-react";
import { formatPrice } from "@/lib/utils";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  ArcElement
);

interface AHPResultsProps {
  results: AHPResult;
  cars: Car[];
  onExport: () => void;
  isExporting: boolean;
}

const AHPResults = ({ results, cars, onExport, isExporting }: AHPResultsProps) => {
  // Map car IDs to names for display
  const carNames = cars.map(car => `${car.brand} ${car.name}`);
  
  // Get the winner (highest score)
  const winnerIndex = results.alternatives.scores.indexOf(
    Math.max(...results.alternatives.scores)
  );
  const winner = cars[winnerIndex];

  // Prepare data for Bar chart
  const barChartData = {
    labels: carNames,
    datasets: [
      {
        label: 'Điểm tổng hợp',
        data: results.alternatives.scores.map(score => parseFloat(score.toFixed(4))),
        backgroundColor: [
          'rgba(29, 94, 145, 0.6)',
          'rgba(255, 107, 53, 0.6)',
          'rgba(54, 162, 235, 0.6)',
          'rgba(75, 192, 192, 0.6)',
          'rgba(153, 102, 255, 0.6)',
        ],
        borderColor: [
          'rgb(29, 94, 145)',
          'rgb(255, 107, 53)',
          'rgb(54, 162, 235)',
          'rgb(75, 192, 192)',
          'rgb(153, 102, 255)',
        ],
        borderWidth: 1,
      },
    ],
  };
  
  // Prepare data for Radar chart
  const radarChartData = {
    labels: results.criteria.names,
    datasets: cars.map((car, index) => ({
      label: `${car.brand} ${car.name}`,
      data: results.criteria.names.map(criterion => {
        const scores = results.alternatives.weightedScores[criterion.toLowerCase()] || [];
        return scores[index] ? parseFloat((scores[index] * 100).toFixed(2)) : 0;
      }),
      backgroundColor: [
        'rgba(29, 94, 145, 0.2)',
        'rgba(255, 107, 53, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(75, 192, 192, 0.2)',
        'rgba(153, 102, 255, 0.2)',
      ][index % 5],
      borderColor: [
        'rgb(29, 94, 145)',
        'rgb(255, 107, 53)',
        'rgb(54, 162, 235)',
        'rgb(75, 192, 192)',
        'rgb(153, 102, 255)',
      ][index % 5],
      borderWidth: 2,
    })),
  };
  
  const barOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Kết quả tổng hợp đánh giá các xe',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 1,
      },
    },
  };
  
  const radarOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'So sánh theo từng tiêu chí',
      },
    },
    scales: {
      r: {
        min: 0,
        max: 50,
        ticks: {
          stepSize: 10,
        },
      },
    },
  };

  // Tạo dữ liệu cho biểu đồ tròn hiển thị trọng số các tiêu chí
  const criteriaChartData = {
    labels: results.criteria.names,
    datasets: [
      {
        data: results.criteria.weights.map(w => parseFloat((w * 100).toFixed(1))),
        backgroundColor: [
          'hsl(210, 70%, 40%)',
          'hsl(25, 85%, 60%)',
          'hsl(145, 65%, 40%)',
          'hsl(270, 75%, 55%)',
          'hsl(350, 70%, 55%)',
        ],
        borderColor: 'white',
        borderWidth: 2,
      },
    ],
  };
  
  const criteriaChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right' as const,
      },
      title: {
        display: true,
        text: 'Tỷ trọng các tiêu chí đánh giá',
        font: {
          size: 14,
        }
      },
    },
  };

  return (
    <div>
      <Card className="mb-8">
        <CardHeader>
          <div className="flex justify-between items-center mb-2">
            <div>
              <CardTitle className="text-2xl">Kết quả phân tích AHP</CardTitle>
              <CardDescription>
                Phân tích sử dụng {results.criteria.names.length} tiêu chí và {cars.length} lựa chọn
              </CardDescription>
            </div>
            <Button 
              onClick={onExport} 
              className="flex items-center" 
              disabled={isExporting}
            >
              <FileDown className="mr-2 h-4 w-4" />
              {isExporting ? "Đang xuất..." : "Xuất báo cáo PDF"}
            </Button>
          </div>
          
          {/* Hộp kết quả dành cho xe tốt nhất */}
          <div className="bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg p-4 mb-2">
            <div className="flex items-center gap-2 mb-4">
              <Award className="text-primary h-6 w-6" />
              <h3 className="text-xl font-semibold text-primary">
                Xe phù hợp nhất: {winner.brand} {winner.name} {winner.model}
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div>
                <div className="relative">
                  <img 
                    src={winner.imageUrl} 
                    alt={winner.name} 
                    className="w-full h-48 object-cover rounded-md border-2 border-primary/20" 
                  />
                  <Badge className="absolute top-2 right-2 bg-primary text-white font-medium">
                    Điểm số: {results.alternatives.scores[winnerIndex].toFixed(4)}
                  </Badge>
                </div>
              </div>
              <div>
                <ul className="space-y-2 text-sm">
                  <li className="flex justify-between border-b pb-1">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <CarIcon className="h-3.5 w-3.5" />Thương hiệu:
                    </span>
                    <span className="font-semibold">{winner.brand}</span>
                  </li>
                  <li className="flex justify-between border-b pb-1">
                    <span className="text-muted-foreground">Loại xe:</span>
                    <span className="font-semibold">{winner.category}</span>
                  </li>
                  <li className="flex justify-between border-b pb-1">
                    <span className="text-muted-foreground">Giá:</span>
                    <span className="font-semibold">{formatPrice(Number(winner.price))}</span>
                  </li>
                  <li className="flex justify-between border-b pb-1">
                    <span className="text-muted-foreground">Công suất:</span>
                    <span className="font-semibold">{winner.horsepower} HP</span>
                  </li>
                  <li className="flex justify-between border-b pb-1">
                    <span className="text-muted-foreground">Tiêu thụ nhiên liệu:</span>
                    <span className="font-semibold">{winner.fuelConsumption} L/100km</span>
                  </li>
                  <li className="flex justify-between border-b pb-1">
                    <span className="text-muted-foreground">Hệ thống an toàn:</span>
                    <span className="font-semibold">{winner.airbags} túi khí, {winner.safetyRating} sao</span>
                  </li>
                  {winner.features && winner.features.length > 0 && (
                    <li className="border-b pb-1">
                      <span className="text-muted-foreground">Tính năng nổi bật:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {winner.features.slice(0, 3).map((feature, idx) => (
                          <Badge key={idx} variant="outline" className="font-normal text-xs">
                            <Check className="h-3 w-3 mr-1" />{feature}
                          </Badge>
                        ))}
                        {winner.features.length > 3 && (
                          <Badge variant="outline" className="font-normal text-xs">
                            +{winner.features.length - 3}
                          </Badge>
                        )}
                      </div>
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="overview">Tổng quan</TabsTrigger>
              <TabsTrigger value="details">Chi tiết đánh giá</TabsTrigger>
              <TabsTrigger value="charts">Biểu đồ so sánh</TabsTrigger>
            </TabsList>
            
            {/* Tab Tổng Quan */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Biểu đồ trọng số tiêu chí */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Trọng số tiêu chí</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] flex items-center justify-center">
                      <Doughnut data={criteriaChartData} options={criteriaChartOptions} />
                    </div>
                    <div className="mt-2 p-3 bg-accent rounded-md">
                      <p className="text-sm mb-1">Chỉ số nhất quán (CR)</p>
                      <p className={`font-medium ${results.criteria.consistencyRatio < 0.1 ? 'text-green-600' : 'text-red-600'}`}>
                        {results.criteria.consistencyRatio.toFixed(3)} 
                        {results.criteria.consistencyRatio < 0.1 ? ' (Chấp nhận được)' : ' (Không nhất quán)'}
                      </p>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Bảng xếp hạng */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Bảng xếp hạng lựa chọn</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <table className="w-full border-collapse">
                      <thead className="bg-muted">
                        <tr>
                          <th className="p-2 text-left text-sm font-medium text-muted-foreground">Xếp hạng</th>
                          <th className="p-2 text-left text-sm font-medium text-muted-foreground">Xe</th>
                          <th className="p-2 text-center text-sm font-medium text-muted-foreground">Điểm số</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[...results.alternatives.scores.map((score, index) => ({ 
                          score, 
                          name: carNames[index], 
                          index
                        }))]
                          .sort((a, b) => b.score - a.score)
                          .map((item, rank) => (
                            <tr key={item.index} className={`border-b ${rank === 0 ? 'bg-primary/5' : ''}`}>
                              <td className="p-2 text-sm font-medium">
                                {rank === 0 ? (
                                  <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white">
                                    1
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-muted text-muted-foreground">
                                    {rank + 1}
                                  </span>
                                )}
                              </td>
                              <td className="p-2 text-sm">
                                {item.name}
                              </td>
                              <td className="p-2 text-sm text-center font-mono">
                                {item.score.toFixed(4)}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </CardContent>
                </Card>
              </div>
              
              <div className="h-[400px]">
                <Bar data={barChartData} options={barOptions} />
              </div>
            </TabsContent>
            
            {/* Tab Chi tiết đánh giá */}
            <TabsContent value="details">
              <div className="space-y-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Trọng số các tiêu chí đánh giá</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <table className="w-full border-collapse">
                      <thead className="bg-muted">
                        <tr>
                          <th className="p-2 text-left text-sm font-medium text-muted-foreground">Tiêu chí</th>
                          <th className="p-2 text-center text-sm font-medium text-muted-foreground">Trọng số</th>
                          <th className="p-2 text-center text-sm font-medium text-muted-foreground">Tỷ lệ phần trăm</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.criteria.names.map((name, index) => (
                          <tr key={index} className="border-b">
                            <td className="p-2 text-sm">{name}</td>
                            <td className="p-2 text-center text-sm font-mono">
                              {results.criteria.weights[index].toFixed(4)}
                            </td>
                            <td className="p-2 text-center">
                              <div className="w-full bg-muted rounded-full h-2.5">
                                <div 
                                  className="bg-primary h-2.5 rounded-full" 
                                  style={{ width: `${(results.criteria.weights[index] * 100).toFixed(1)}%` }}
                                ></div>
                              </div>
                              <span className="text-xs text-muted-foreground">
                                {(results.criteria.weights[index] * 100).toFixed(1)}%
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Điểm số chi tiết theo từng tiêu chí</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead className="bg-muted">
                          <tr>
                            <th className="p-2 text-left text-sm font-medium text-muted-foreground sticky left-0 bg-muted">Xe</th>
                            {results.criteria.names.map((criterion, idx) => (
                              <th key={idx} className="p-2 text-center text-sm font-medium text-muted-foreground whitespace-nowrap">
                                {criterion}
                              </th>
                            ))}
                            <th className="p-2 text-center text-sm font-medium text-muted-foreground whitespace-nowrap">
                              Tổng điểm
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {cars.map((car, carIndex) => (
                            <tr key={carIndex} className={`border-b ${carIndex === winnerIndex ? 'bg-primary/5' : ''}`}>
                              <td className="p-2 text-sm font-medium sticky left-0 bg-white">
                                {car.brand} {car.name}
                              </td>
                              {results.criteria.names.map((criterion, idx) => {
                                const scores = results.alternatives.weightedScores[criterion.toLowerCase()] || [];
                                const score = scores[carIndex] || 0;
                                return (
                                  <td key={idx} className="p-2 text-center text-sm font-mono">
                                    {score.toFixed(4)}
                                  </td>
                                );
                              })}
                              <td className="p-2 text-center text-sm font-medium bg-muted/30">
                                {results.alternatives.scores[carIndex].toFixed(4)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Tab Biểu đồ */}
            <TabsContent value="charts">
              <div className="space-y-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Biểu đồ so sánh điểm tổng hợp</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[400px]">
                      <Bar data={barChartData} options={{
                        ...barOptions,
                        indexAxis: 'y',
                        plugins: {
                          ...barOptions.plugins,
                          title: {
                            ...barOptions.plugins.title,
                            text: 'So sánh điểm tổng hợp của các xe'
                          }
                        }
                      }} />
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Biểu đồ radar thể hiện ưu điểm của từng xe</CardTitle>
                    <CardDescription>
                      Biểu đồ thể hiện điểm mạnh, điểm yếu của từng xe theo các tiêu chí
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[400px] flex items-center justify-center">
                      <Radar data={radarChartData} options={radarOptions} />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default AHPResults;
