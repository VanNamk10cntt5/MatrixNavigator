import { useState } from "react";
import { useLocation } from "wouter";
import { useCars } from "@/hooks/useCars";
import { useAHP } from "@/hooks/useAHP";
import SelectedCarsList from "@/components/SelectedCarsList";
import StepIndicator from "@/components/StepIndicator";
import AHPMatrix from "@/components/AHPMatrix";
import AHPResults from "@/components/AHPResults";
import { Button } from "@/components/ui/button";
import { ahpCriteria } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, ArrowRight, FileDown } from "lucide-react";

const AHPAnalysis = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { selectedCars, removeCar } = useCars();
  const { 
    matrix, 
    setMatrix, 
    step, 
    setStep, 
    alternativeMatrices, 
    setAlternativeMatrix,
    results,
    setResults
  } = useAHP();

  // Calculate AHP mutation
  const calculateAHP = useMutation({
    mutationFn: async (data: { 
      criteriaMatrix: number[][], 
      alternativeMatrices: { [key: string]: number[][] },
      alternatives: string[]
    }) => {
      const response = await apiRequest('POST', '/api/ahp/calculate', data);
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      setStep(3);
    },
    onError: (error) => {
      toast({
        title: "Lỗi tính toán",
        description: error.message || "Không thể tính toán kết quả AHP",
        variant: "destructive"
      });
    }
  });

  // Generate report mutation
  const generateReport = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/ahp/report', {
        results,
        cars: selectedCars
      });
      return response.blob();
    },
    onSuccess: (blob) => {
      // Create a download link and click it
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'AHP_Analysis_Report.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Báo cáo đã được tạo",
        description: "Tải xuống báo cáo phân tích AHP thành công",
      });
    },
    onError: () => {
      toast({
        title: "Lỗi tạo báo cáo",
        description: "Không thể tạo báo cáo PDF",
        variant: "destructive"
      });
    }
  });

  const handleNextStep = () => {
    if (step === 1) {
      // Validate consistency before proceeding
      const isValid = validateMatrix();
      if (!isValid) {
        toast({
          title: "Ma trận không hợp lệ",
          description: "Vui lòng đảm bảo ma trận nhất quán (CR < 0.1)",
          variant: "destructive"
        });
        return;
      }
      setStep(2);
    } else if (step === 2) {
      // Process and submit all matrices
      calculateAHP.mutate({
        criteriaMatrix: matrix,
        alternativeMatrices,
        alternatives: selectedCars.map(car => car.id.toString())
      });
    }
  };

  const handlePreviousStep = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      setLocation("/");
    }
  };

  const handleExportReport = () => {
    if (results) {
      generateReport.mutate();
    }
  };

  const validateMatrix = () => {
    // This is just a placeholder - the actual validation would be done on the server
    // and returned in the results. For the UI flow, we'll assume it's valid.
    return true;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-heading font-bold text-gray-700">Phân Tích AHP</h1>
        <p className="text-gray-600 mt-2">So sánh cặp tiêu chí dựa trên thang điểm Saaty (1-9)</p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-4 mb-8">
        <h2 className="text-lg font-heading font-semibold text-gray-700 mb-4">Xe đã chọn để phân tích</h2>
        {selectedCars.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {selectedCars.map(car => (
              <div key={car.id} className="bg-gray-100 rounded-lg p-3">
                <div className="flex items-center mb-2">
                  <img 
                    src={car.imageUrl} 
                    alt={car.name} 
                    className="w-16 h-10 object-cover rounded mr-2"
                  />
                  <div>
                    <h3 className="font-medium text-sm">{car.name}</h3>
                    <p className="text-xs text-gray-600">{car.model}</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-red-500 hover:text-red-600 text-xs flex items-center w-full justify-center"
                  onClick={() => removeCar(car.id)}
                  disabled={step !== 1}
                >
                  <span className="material-icons text-sm mr-1">remove_circle_outline</span>
                  Loại bỏ
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-6 border-2 border-dashed border-gray-300 rounded-lg text-center">
            <span className="material-icons text-gray-400 text-3xl mb-2">warning</span>
            <p className="text-gray-500">Bạn chưa chọn xe nào để phân tích</p>
            <Button 
              variant="outline"
              className="mt-4"
              onClick={() => setLocation("/")}
            >
              Quay lại chọn xe
            </Button>
          </div>
        )}
      </div>

      <StepIndicator currentStep={step} />

      {step === 1 && (
        <AHPMatrix 
          matrix={matrix}
          setMatrix={setMatrix}
          criteria={ahpCriteria}
        />
      )}

      {step === 2 && (
        <div className="bg-white rounded-lg shadow-md p-4 mb-8">
          <h2 className="text-lg font-heading font-semibold text-gray-700 mb-4">
            So sánh các xe theo từng tiêu chí
          </h2>
          <p className="text-gray-600 text-sm mb-6">
            Nhập giá trị so sánh cho từng cặp xe theo mỗi tiêu chí (1-9)
          </p>
          
          {ahpCriteria.map((criterion, index) => (
            <div key={criterion} className="mb-8">
              <h3 className="text-md font-heading font-semibold text-gray-700 mb-4">
                Tiêu chí: {criterion}
              </h3>
              <AHPMatrix 
                matrix={alternativeMatrices[criterion] || []}
                setMatrix={(newMatrix) => setAlternativeMatrix(criterion, newMatrix)}
                criteria={selectedCars.map(car => `${car.brand} ${car.name}`)}
                hideResults
              />
              <div className="border-b border-gray-200 my-6"></div>
            </div>
          ))}
        </div>
      )}

      {step === 3 && results && (
        <AHPResults 
          results={results} 
          cars={selectedCars}
          onExport={handleExportReport}
          isExporting={generateReport.isPending}
        />
      )}

      {selectedCars.length > 0 && step !== 3 && (
        <div className="flex justify-between items-center mt-6">
          <Button
            variant="outline"
            className="flex items-center"
            onClick={handlePreviousStep}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {step > 1 ? "Quay lại" : "Về trang chọn xe"}
          </Button>
          
          <Button
            className="flex items-center"
            onClick={handleNextStep}
            disabled={calculateAHP.isPending}
          >
            {calculateAHP.isPending ? "Đang tính toán..." : (
              <>
                {step === 1 ? "Tiếp theo" : "Tính toán kết quả"}
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      )}

      {step === 3 && (
        <div className="flex justify-between items-center mt-6">
          <Button
            variant="outline"
            className="flex items-center"
            onClick={() => setLocation("/")}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Chọn lại xe
          </Button>
          
          <Button
            className="flex items-center"
            onClick={handleExportReport}
            disabled={generateReport.isPending}
          >
            {generateReport.isPending ? "Đang tạo báo cáo..." : (
              <>
                Xuất báo cáo PDF
                <FileDown className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
};

export default AHPAnalysis;
