import { useState } from "react";
import { useLocation } from "wouter";
import FilterPanel from "@/components/FilterPanel";
import SelectedCarsList from "@/components/SelectedCarsList";
import CarCard from "@/components/CarCard";
import { useCars } from "@/hooks/useCars";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { carCategories } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

const VehicleSelection = () => {
  const [, setLocation] = useLocation();
  const { selectedCars, selectCar, removeCar, canAddMoreCars } = useCars();
  const [activeTab, setActiveTab] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    category: "",
    priceMax: 5000,
    brand: "",
    horsepowerMin: 100,
    fuelConsumptionMax: 15,
    sort: "price-asc"
  });

  const { data: cars = [], isLoading } = useQuery({
    queryKey: ['/api/cars', filters],
  });

  const handleFilterChange = (newFilters: any) => {
    setFilters({ ...filters, ...newFilters });
    setCurrentPage(1);
  };

  const handleResetFilters = () => {
    setFilters({
      category: "",
      priceMax: 5000,
      brand: "",
      horsepowerMin: 100,
      fuelConsumptionMax: 15,
      sort: "price-asc"
    });
    setCurrentPage(1);
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    if (value === "all") {
      handleFilterChange({ category: "" });
    } else {
      handleFilterChange({ category: value });
    }
  };

  const handleGoToAnalysis = () => {
    setLocation("/analysis");
  };

  const paginatedCars = isLoading ? [] : cars;
  const totalPages = Math.ceil(cars.length / 6);
  
  const renderPagination = () => {
    if (totalPages <= 1) return null;
    
    return (
      <div className="mt-8 flex justify-center">
        <nav className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            <span className="material-icons text-sm">navigate_before</span>
          </Button>
          
          {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
            const pageNum = i + 1;
            return (
              <Button
                key={pageNum}
                variant={currentPage === pageNum ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentPage(pageNum)}
              >
                {pageNum}
              </Button>
            );
          })}
          
          {totalPages > 5 && <span className="text-neutral-500">...</span>}
          
          {totalPages > 5 && (
            <Button
              variant={currentPage === totalPages ? "default" : "outline"}
              size="sm"
              onClick={() => setCurrentPage(totalPages)}
            >
              {totalPages}
            </Button>
          )}
          
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            <span className="material-icons text-sm">navigate_next</span>
          </Button>
        </nav>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-heading font-bold text-gray-700">Chọn Xe Phù Hợp Với Bạn</h1>
        <p className="text-gray-600 mt-2">Hãy chọn các xe bạn muốn so sánh từ các danh mục dưới đây</p>
      </div>

      <FilterPanel 
        filters={filters} 
        onFilterChange={handleFilterChange} 
        onReset={handleResetFilters} 
      />

      <SelectedCarsList 
        selectedCars={selectedCars} 
        onRemove={removeCar} 
        onAnalyze={handleGoToAnalysis} 
      />

      <div className="mb-8">
        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="flex overflow-x-auto space-x-4 pb-2">
            <TabsTrigger value="all">Tất cả</TabsTrigger>
            {carCategories.map(category => (
              <TabsTrigger key={category} value={category}>{category}</TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-white rounded-lg shadow-md h-96 animate-pulse">
              <div className="w-full h-48 bg-gray-200 rounded-t-lg"></div>
              <div className="p-4 space-y-3">
                <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                <div className="h-5 bg-gray-200 rounded w-1/2"></div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="h-4 bg-gray-200 rounded"></div>
                  <div className="h-4 bg-gray-200 rounded"></div>
                  <div className="h-4 bg-gray-200 rounded"></div>
                  <div className="h-4 bg-gray-200 rounded"></div>
                </div>
                <div className="flex justify-between items-center pt-2">
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/3"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {paginatedCars.map(car => (
              <CarCard 
                key={car.id} 
                car={car} 
                isSelected={selectedCars.some(c => c.id === car.id)}
                onSelect={() => selectCar(car)}
                canSelect={canAddMoreCars}
              />
            ))}
          </div>
          {renderPagination()}
        </>
      )}
    </div>
  );
};

export default VehicleSelection;
