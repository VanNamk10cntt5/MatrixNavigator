import { ahpCriteria } from "@shared/schema";

// AHP Scale descriptions
export const AHP_SCALE_DESCRIPTIONS = {
  1: "Hai yếu tố quan trọng như nhau",
  2: "Yếu tố này quan trọng hơn một chút",
  3: "Yếu tố này hơi quan trọng hơn",
  4: "Yếu tố này quan trọng hơn vừa phải",
  5: "Yếu tố này khá quan trọng hơn",
  6: "Yếu tố này quan trọng hơn nhiều",
  7: "Yếu tố này rất quan trọng hơn",
  8: "Yếu tố này cực kỳ quan trọng hơn gần như tuyệt đối",
  9: "Yếu tố này cực kỳ quan trọng hơn tuyệt đối",
};

// Human-readable criteria names
export const CRITERIA_DISPLAY_NAMES: Record<string, string> = {
  price: "Giá",
  horsepower: "Công suất",
  fuelConsumption: "Tiêu thụ nhiên liệu",
  safety: "Hệ thống an toàn",
  comfort: "Thiết kế & tiện nghi",
  brand: "Thương hiệu"
};

// Default criteria weights
export const DEFAULT_CRITERIA_WEIGHTS = ahpCriteria.reduce((acc, criterion, index) => {
  acc[criterion] = 1 / ahpCriteria.length;
  return acc;
}, {} as Record<string, number>);

// Maximum number of cars to compare
export const MAX_SELECTED_CARS = 5;

// Random Consistency Index (RI) values for different matrix sizes
export const RANDOM_CONSISTENCY_INDEX = [
  0,    // n=0 (not used)
  0,    // n=1
  0,    // n=2
  0.58, // n=3
  0.9,  // n=4
  1.12, // n=5
  1.24, // n=6
  1.32, // n=7
  1.41, // n=8
  1.45, // n=9
  1.49  // n=10
];
