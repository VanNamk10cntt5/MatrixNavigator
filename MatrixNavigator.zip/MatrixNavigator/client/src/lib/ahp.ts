// AHP Calculator Functions

/**
 * Calculate the weights from a pairwise comparison matrix using the eigenvalue method
 * @param matrix The pairwise comparison matrix
 * @returns An array of weights
 */
export function calculateWeights(matrix: number[][]): number[] {
  const n = matrix.length;
  
  // If matrix is empty or invalid, return empty array
  if (n === 0 || matrix.some(row => row.length !== n)) {
    return [];
  }
  
  // Step 1: Sum each column
  const columnSums = Array(n).fill(0);
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      columnSums[j] += matrix[i][j];
    }
  }
  
  // Step 2: Normalize the matrix by dividing each entry by its column sum
  const normalizedMatrix = matrix.map((row, i) => 
    row.map((cell, j) => cell / columnSums[j])
  );
  
  // Step 3: Calculate the average of each row to get the weights
  const weights = normalizedMatrix.map(row => 
    row.reduce((sum, cell) => sum + cell, 0) / n
  );
  
  return weights;
}

/**
 * Calculate consistency ratio to check if the pairwise comparisons are consistent
 * @param matrix The pairwise comparison matrix
 * @param weights The calculated weights
 * @returns Consistency metrics including lambdaMax, CI, CR, and isConsistent flag
 */
export function calculateConsistency(matrix: number[][], weights: number[]): {
  lambdaMax: number;
  ci: number;
  cr: number;
  isConsistent: boolean;
} {
  const n = matrix.length;
  
  // If matrix is empty or invalid, return default values
  if (n === 0 || matrix.some(row => row.length !== n) || weights.length !== n) {
    return { lambdaMax: 0, ci: 0, cr: 0, isConsistent: true };
  }
  
  // Step 1: Calculate weighted sum vector
  const weightedSum = Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      weightedSum[i] += matrix[i][j] * weights[j];
    }
  }
  
  // Step 2: Calculate lambda values
  const lambdaValues = weightedSum.map((sum, i) => sum / weights[i]);
  
  // Step 3: Calculate lambda max (average of lambda values)
  const lambdaMax = lambdaValues.reduce((sum, value) => sum + value, 0) / n;
  
  // Step 4: Calculate Consistency Index (CI)
  const ci = (lambdaMax - n) / (n - 1);
  
  // Step 5: Calculate Consistency Ratio (CR) using Random Index (RI)
  // RI values for n = 1 to 10
  const ri = [0, 0, 0.58, 0.9, 1.12, 1.24, 1.32, 1.41, 1.45, 1.49];
  const cr = ci / (n <= 10 ? ri[n-1] : 1.5);
  
  // A CR value of 0.1 or less is generally considered acceptable
  const isConsistent = cr <= 0.1;
  
  return { lambdaMax, ci, cr, isConsistent };
}

/**
 * Calculate the final scores for alternatives based on criteria weights and alternative scores
 * @param criteriaWeights Weights for each criterion
 * @param alternativeScores Scores for each alternative per criterion
 * @returns Final scores for each alternative
 */
export function calculateFinalScores(
  criteriaWeights: number[],
  alternativeScores: Record<string, number[]>
): number[] {
  const criteriaNames = Object.keys(alternativeScores);
  
  // If no data, return empty array
  if (criteriaNames.length === 0 || criteriaWeights.length === 0) {
    return [];
  }
  
  // Get the number of alternatives from the first criterion's scores
  const numAlternatives = alternativeScores[criteriaNames[0]].length;
  
  // Initialize final scores array
  const finalScores = Array(numAlternatives).fill(0);
  
  // For each criterion
  criteriaNames.forEach((criterion, i) => {
    const scores = alternativeScores[criterion];
    const weight = criteriaWeights[i];
    
    // For each alternative
    for (let j = 0; j < numAlternatives; j++) {
      finalScores[j] += scores[j] * weight;
    }
  });
  
  return finalScores;
}
