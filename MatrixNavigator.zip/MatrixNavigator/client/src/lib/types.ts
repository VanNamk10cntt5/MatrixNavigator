import { Car } from "@shared/schema";

// Step indicator props
export interface StepProps {
  number: number;
  title: string;
  description: string;
}

// Extended car type with selection information
export interface CarWithSelection extends Car {
  isSelected: boolean;
}

// Car filter options
export interface CarFilters {
  category: string;
  priceMax: number;
  brand: string;
  horsepowerMin: number;
  fuelConsumptionMax: number;
  sort: string;
}

// Alternative matrix type
export interface AlternativeMatrices {
  [criterion: string]: number[][];
}

// AHP state type
export interface AHPState {
  matrix: number[][];
  step: number;
  alternativeMatrices: AlternativeMatrices;
  results: any | null;
}

// Car selection state
export interface CarSelectionState {
  selectedCars: Car[];
  canAddMoreCars: boolean;
}
