import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

document.title = "AutoAHP - Hệ thống so sánh và lựa chọn ô tô phù hợp nhất";

createRoot(document.getElementById("root")!).render(<App />);
