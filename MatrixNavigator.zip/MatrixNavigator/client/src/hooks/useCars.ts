import { createContext, useContext, useState, ReactNode } from 'react';
import { Car } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { MAX_SELECTED_CARS } from '@/lib/constants';
import * as React from 'react';

interface CarSelectionContextType {
  selectedCars: Car[];
  selectCar: (car: Car) => void;
  removeCar: (id: number) => void;
  clearSelectedCars: () => void;
  canAddMoreCars: boolean;
}

const CarSelectionContext = createContext<CarSelectionContextType | undefined>(undefined);

export function CarSelectionProvider({ children }: { children: ReactNode }) {
  const [selectedCars, setSelectedCars] = useState<Car[]>([]);
  const { toast } = useToast();
  
  const canAddMoreCars = selectedCars.length < MAX_SELECTED_CARS;

  const selectCar = (car: Car) => {
    // Check if car is already selected
    if (selectedCars.some(c => c.id === car.id)) {
      toast({
        title: "Xe đã được chọn",
        description: `${car.brand} ${car.name} đã có trong danh sách so sánh`,
        variant: "destructive"
      });
      return;
    }
    
    // Check if max cars reached
    if (selectedCars.length >= MAX_SELECTED_CARS) {
      toast({
        title: "Đã đạt giới hạn",
        description: `Bạn chỉ có thể chọn tối đa ${MAX_SELECTED_CARS} xe để so sánh`,
        variant: "destructive"
      });
      return;
    }
    
    setSelectedCars([...selectedCars, car]);
    
    toast({
      title: "Đã thêm xe",
      description: `${car.brand} ${car.name} đã được thêm vào danh sách so sánh`
    });
  };

  const removeCar = (id: number) => {
    const carToRemove = selectedCars.find(c => c.id === id);
    
    if (carToRemove) {
      setSelectedCars(selectedCars.filter(c => c.id !== id));
      
      toast({
        title: "Đã loại bỏ xe",
        description: `${carToRemove.brand} ${carToRemove.name} đã bị loại khỏi danh sách so sánh`
      });
    }
  };

  const clearSelectedCars = () => {
    setSelectedCars([]);
    
    toast({
      title: "Đã xóa danh sách",
      description: "Tất cả xe đã bị loại khỏi danh sách so sánh"
    });
  };

  return React.createElement(CarSelectionContext.Provider, {
    value: {
      selectedCars,
      selectCar,
      removeCar,
      clearSelectedCars,
      canAddMoreCars
    }
  }, children);
};

export const useCars = () => {
  const context = useContext(CarSelectionContext);
  if (context === undefined) {
    throw new Error('useCars must be used within a CarSelectionProvider');
  }
  return context;
};
