import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { AHPMatrix, AHPResult, ahpCriteria } from '@shared/schema';
import * as React from 'react';

interface AHPContextType {
  matrix: AHPMatrix;
  setMatrix: (matrix: AHPMatrix) => void;
  step: number;
  setStep: (step: number) => void;
  alternativeMatrices: { [key: string]: AHPMatrix };
  setAlternativeMatrix: (criterion: string, matrix: AHPMatrix) => void;
  results: AHPResult | null;
  setResults: (results: AHPResult | null) => void;
}

const AHPContext = createContext<AHPContextType | undefined>(undefined);

// Fix for React context provider
export function AHPProvider({ children }: { children: ReactNode }) {
  const [step, setStep] = useState<number>(1);
  const [matrix, setMatrix] = useState<AHPMatrix>([]);
  const [alternativeMatrices, setAlternativeMatrices] = useState<{ [key: string]: AHPMatrix }>({});
  const [results, setResults] = useState<AHPResult | null>(null);

  // Initialize the criteria matrix with default values
  useEffect(() => {
    if (matrix.length === 0) {
      const n = ahpCriteria.length;
      const initialMatrix = Array(n).fill(0).map((_, i) => 
        Array(n).fill(0).map((_, j) => {
          if (i === j) return 1;
          return 0;
        })
      );
      setMatrix(initialMatrix);
    }
  }, [matrix]);

  const setAlternativeMatrix = (criterion: string, newMatrix: AHPMatrix) => {
    setAlternativeMatrices(prev => ({
      ...prev,
      [criterion]: newMatrix
    }));
  };

  return React.createElement(AHPContext.Provider, {
    value: {
      matrix,
      setMatrix,
      step,
      setStep,
      alternativeMatrices,
      setAlternativeMatrix,
      results,
      setResults
    }
  }, children);
};

export const useAHP = () => {
  const context = useContext(AHPContext);
  if (context === undefined) {
    throw new Error('useAHP must be used within an AHPProvider');
  }
  return context;
};
