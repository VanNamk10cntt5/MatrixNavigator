import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { queryClient } from "./lib/queryClient";
import NotFound from "@/pages/not-found";
import VehicleSelection from "@/pages/VehicleSelection";
import AHPAnalysis from "@/pages/AHPAnalysis";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { CarSelectionProvider } from "@/hooks/useCars";
import { AHPProvider } from "@/hooks/useAHP";

function Router() {
  return (
    <Switch>
      <Route path="/" component={VehicleSelection} />
      <Route path="/analysis" component={AHPAnalysis} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <CarSelectionProvider>
          <AHPProvider>
            <div className="flex flex-col min-h-screen">
              <Navbar />
              <main className="flex-grow">
                <Router />
              </main>
              <Footer />
            </div>
            <Toaster />
          </AHPProvider>
        </CarSelectionProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
