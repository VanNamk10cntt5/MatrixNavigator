import { cars, type Car, type InsertCar, carCategories } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  getCars(filters?: {
    category?: string;
    priceMax?: number;
    brand?: string;
    horsepowerMin?: number;
    fuelConsumptionMax?: number;
  }): Promise<Car[]>;
  getCarById(id: number): Promise<Car | undefined>;
  createCar(car: InsertCar): Promise<Car>;
  initializeSampleData(): Promise<void>;
}

export class MemStorage implements IStorage {
  private cars: Map<number, Car>;
  private currentId: number;

  constructor() {
    this.cars = new Map();
    this.currentId = 1;
  }

  async getCars(filters?: {
    category?: string;
    priceMax?: number;
    brand?: string;
    horsepowerMin?: number;
    fuelConsumptionMax?: number;
  }): Promise<Car[]> {
    let result = Array.from(this.cars.values());

    if (filters) {
      if (filters.category && filters.category !== "") {
        result = result.filter(car => car.category === filters.category);
      }

      if (filters.priceMax) {
        result = result.filter(car => Number(car.price) <= filters.priceMax!);
      }

      if (filters.brand && filters.brand !== "") {
        result = result.filter(car => car.brand === filters.brand);
      }

      if (filters.horsepowerMin) {
        result = result.filter(car => car.horsepower >= filters.horsepowerMin!);
      }

      if (filters.fuelConsumptionMax) {
        result = result.filter(car => Number(car.fuelConsumption) <= filters.fuelConsumptionMax!);
      }
    }

    return result;
  }

  async getCarById(id: number): Promise<Car | undefined> {
    return this.cars.get(id);
  }

  async createCar(insertCar: InsertCar): Promise<Car> {
    const id = this.currentId++;
    const car: Car = { ...insertCar, id };
    this.cars.set(id, car);
    return car;
  }

  async initializeSampleData(): Promise<void> {
    // Only initialize if no data exists
    if (this.cars.size === 0) {
      // Sedan group
      await this.createCar({
        name: "Camry",
        model: "2.5Q",
        brand: "Toyota",
        category: "Sedan",
        price: 1235000000,
        horsepower: 207,
        fuelConsumption: 7.1,
        airbags: 7,
        safetyRating: 5,
        features: ["Hệ thống cảnh báo điểm mù", "Cảm biến đỗ xe", "Hỗ trợ khởi hành ngang dốc", "Camera 360"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=toyota&modelFamily=camry&zoomType=fullscreen"
      });

      await this.createCar({
        name: "Civic",
        model: "RS",
        brand: "Honda",
        category: "Sedan",
        price: 870000000,
        horsepower: 180,
        fuelConsumption: 6.5,
        airbags: 6,
        safetyRating: 5,
        features: ["Honda Sensing", "Apple CarPlay/Android Auto", "Cảm biến đỗ xe", "Kiểm soát hành trình"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=honda&modelFamily=civic&zoomType=fullscreen"
      });

      await this.createCar({
        name: "3",
        model: "Luxury",
        brand: "Mazda",
        category: "Sedan",
        price: 699000000,
        horsepower: 150,
        fuelConsumption: 6.3,
        airbags: 6,
        safetyRating: 5,
        features: ["Màn hình HUD", "Hệ thống âm thanh Bose", "Kiểm soát hành trình", "Hỗ trợ phanh thông minh"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=mazda&modelFamily=3&zoomType=fullscreen"
      });

      // SUV group
      await this.createCar({
        name: "Fortuner",
        model: "2.8AT",
        brand: "Toyota",
        category: "SUV",
        price: 1426000000,
        horsepower: 201,
        fuelConsumption: 8.8,
        airbags: 7,
        safetyRating: 5,
        features: ["Hệ thống ổn định thân xe", "Hệ thống kiểm soát lực kéo", "Hỗ trợ đổ đèo", "Khóa vi sai"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=toyota&modelFamily=fortuner&zoomType=fullscreen"
      });

      await this.createCar({
        name: "Everest",
        model: "Titanium+",
        brand: "Ford",
        category: "SUV",
        price: 1452000000,
        horsepower: 210,
        fuelConsumption: 8.5,
        airbags: 7,
        safetyRating: 5,
        features: ["Ford Co-Pilot 360", "Địa hình thông minh", "Hệ thống âm thanh Bang & Olufsen", "Màn hình giải trí 12 inch"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=ford&modelFamily=everest&zoomType=fullscreen"
      });

      await this.createCar({
        name: "Santa Fe",
        model: "Premium",
        brand: "Hyundai",
        category: "SUV",
        price: 1140000000,
        horsepower: 188,
        fuelConsumption: 7.6,
        airbags: 6,
        safetyRating: 5,
        features: ["Hyundai SmartSense", "Ghế sưởi/làm mát", "Cửa sổ trời toàn cảnh", "Màn hình 10.25 inch"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=hyundai&modelFamily=santa+fe&zoomType=fullscreen"
      });

      // Hatchback group
      await this.createCar({
        name: "Yaris",
        model: "G",
        brand: "Toyota",
        category: "Hatchback",
        price: 668000000,
        horsepower: 107,
        fuelConsumption: 5.8,
        airbags: 7,
        safetyRating: 5,
        features: ["Toyota Safety Sense", "Hệ thống giải trí 7 inch", "Camera lùi", "Đèn LED"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=toyota&modelFamily=yaris&zoomType=fullscreen"
      });

      await this.createCar({
        name: "Jazz",
        model: "RS",
        brand: "Honda",
        category: "Hatchback",
        price: 544000000,
        horsepower: 118,
        fuelConsumption: 5.6,
        airbags: 6,
        safetyRating: 5,
        features: ["Hệ thống VTEC Turbo", "Cửa sổ trời", "Không gian nội thất linh hoạt", "Kết nối Apple CarPlay"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=honda&modelFamily=jazz&zoomType=fullscreen"
      });

      await this.createCar({
        name: "2",
        model: "Sport",
        brand: "Mazda",
        category: "Hatchback",
        price: 564000000,
        horsepower: 115,
        fuelConsumption: 5.9,
        airbags: 6,
        safetyRating: 4,
        features: ["G-Vectoring Control", "Màn hình HUD", "Đèn pha LED thích ứng", "Kiểm soát hành trình thích ứng"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=mazda&modelFamily=2&zoomType=fullscreen"
      });

      // Pickup group
      await this.createCar({
        name: "Hilux",
        model: "2.8L 4x4 AT",
        brand: "Toyota",
        category: "Pickup",
        price: 913000000,
        horsepower: 201,
        fuelConsumption: 8.9,
        airbags: 7,
        safetyRating: 5,
        features: ["Hỗ trợ đổ đèo", "Khóa vi sai điện tử", "Kiểm soát lực kéo", "Hỗ trợ khởi hành ngang dốc"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=toyota&modelFamily=hilux&zoomType=fullscreen"
      });

      await this.createCar({
        name: "Ranger",
        model: "Wildtrak",
        brand: "Ford",
        category: "Pickup",
        price: 965000000,
        horsepower: 210,
        fuelConsumption: 8.1,
        airbags: 6,
        safetyRating: 5,
        features: ["Hỗ trợ đỗ xe tự động", "Cảnh báo làn đường", "Hệ thống giảm thiểu va chạm", "Màn hình cảm ứng 8 inch"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=ford&modelFamily=ranger&zoomType=fullscreen"
      });

      await this.createCar({
        name: "Colorado",
        model: "High Country",
        brand: "Chevrolet",
        category: "Pickup",
        price: 789000000,
        horsepower: 197,
        fuelConsumption: 8.3,
        airbags: 6,
        safetyRating: 4,
        features: ["Kiểm soát hành trình", "Camera lùi", "Hỗ trợ đỗ xe", "Hệ thống thông tin giải trí MyLink"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=chevrolet&modelFamily=colorado&zoomType=fullscreen"
      });

      // Crossover group
      await this.createCar({
        name: "Corolla Cross",
        model: "1.8HV",
        brand: "Toyota",
        category: "Crossover",
        price: 910000000,
        horsepower: 170,
        fuelConsumption: 4.2,
        airbags: 7,
        safetyRating: 5,
        features: ["Hệ thống Hybrid", "Toyota Safety Sense", "Camera 360", "Cửa sổ trời"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=toyota&modelFamily=corolla+cross&zoomType=fullscreen"
      });

      await this.createCar({
        name: "HR-V",
        model: "L",
        brand: "Honda",
        category: "Crossover",
        price: 866000000,
        horsepower: 174,
        fuelConsumption: 6.7,
        airbags: 6,
        safetyRating: 5,
        features: ["Honda Sensing", "Cửa sổ trời", "Ghế sưởi", "Màn hình hiển thị đa thông tin"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=honda&modelFamily=hr-v&zoomType=fullscreen"
      });

      await this.createCar({
        name: "CX-30",
        model: "Premium",
        brand: "Mazda",
        category: "Crossover",
        price: 839000000,
        horsepower: 154,
        fuelConsumption: 6.8,
        airbags: 7,
        safetyRating: 5,
        features: ["Hệ thống i-Activsense", "Màn hình HUD", "Hệ thống âm thanh Bose", "Cửa sổ trời"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=mazda&modelFamily=cx-30&zoomType=fullscreen"
      });

      // MPV group
      await this.createCar({
        name: "Innova",
        model: "Venture",
        brand: "Toyota",
        category: "MPV",
        price: 885000000,
        horsepower: 168,
        fuelConsumption: 9.1,
        airbags: 7,
        safetyRating: 4,
        features: ["Hệ thống ổn định thân xe", "Camera lùi", "Cảm biến đỗ xe", "Màn hình cảm ứng 8 inch"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=toyota&modelFamily=innova&angle=23&zoomType=fullscreen"
      });

      await this.createCar({
        name: "Odyssey",
        model: "Premium",
        brand: "Honda",
        category: "MPV",
        price: 1399000000,
        horsepower: 175,
        fuelConsumption: 8.8,
        airbags: 6,
        safetyRating: 5,
        features: ["Cửa điện thông minh", "Hàng ghế thứ 2 Captain", "Hệ thống giải trí cho hàng ghế sau", "Camera 360"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=honda&modelFamily=odyssey&zoomType=fullscreen"
      });

      await this.createCar({
        name: "Carnival",
        model: "Premium",
        brand: "KIA",
        category: "MPV",
        price: 1359000000,
        horsepower: 190,
        fuelConsumption: 8.5,
        airbags: 8,
        safetyRating: 5,
        features: ["Ghế chỉnh điện", "Cửa lùa điện", "Màn hình giải trí 12.3 inch", "Hệ thống âm thanh Bose"],
        imageUrl: "https://cdn.imagin.studio/getImage?customer=img&make=kia&modelFamily=carnival&zoomType=fullscreen"
      });
    }
  }
}

export const storage = new MemStorage();
