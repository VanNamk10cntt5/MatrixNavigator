import { AHPMatrix, AHPResult, Car, ahpCriteria } from "@shared/schema";
import { CRITERIA_DISPLAY_NAMES, RANDOM_CONSISTENCY_INDEX } from "@/lib/constants";

interface AHPCalculator {
  calculateAHP(
    criteriaMatrix: AHPMatrix,
    alternativeMatrices: { [key: string]: AHPMatrix }
  ): AHPResult;
  calculateWeights(matrix: AHPMatrix): number[];
  calculateConsistency(matrix: AHPMatrix, weights: number[]): {
    lambdaMax: number;
    ci: number;
    cr: number;
    isConsistent: boolean;
  };
  generateReport(results: AHPResult, cars: Car[]): Promise<Buffer>;
}

class AHPCalculatorImplementation implements AHPCalculator {
  // Calculate final AHP result
  calculateAHP(
    criteriaMatrix: AHPMatrix,
    alternativeMatrices: { [key: string]: AHPMatrix }
  ): AHPResult {
    // Calculate criteria weights
    const criteriaWeights = this.calculateWeights(criteriaMatrix);
    const criteriaConsistency = this.calculateConsistency(criteriaMatrix, criteriaWeights);
    
    // Calculate alternative weights for each criterion
    const alternativesWeightedScores: { [key: string]: number[] } = {};
    
    ahpCriteria.forEach((criterion, index) => {
      const matrix = alternativeMatrices[criterion];
      if (matrix && matrix.length > 0) {
        const weights = this.calculateWeights(matrix);
        alternativesWeightedScores[criterion] = weights;
      }
    });
    
    // Calculate final scores
    const numAlternatives = Object.values(alternativesWeightedScores)[0]?.length || 0;
    const finalScores = Array(numAlternatives).fill(0);
    
    // Multiply each alternative score by the criterion weight and sum
    ahpCriteria.forEach((criterion, index) => {
      const scores = alternativesWeightedScores[criterion] || [];
      const weight = criteriaWeights[index];
      
      for (let i = 0; i < numAlternatives; i++) {
        finalScores[i] += scores[i] * weight;
      }
    });
    
    // Format result
    return {
      criteria: {
        names: ahpCriteria.map(criterion => CRITERIA_DISPLAY_NAMES[criterion] || criterion),
        weights: criteriaWeights,
        consistencyRatio: criteriaConsistency.cr,
        lambdaMax: criteriaConsistency.lambdaMax,
        consistencyIndex: criteriaConsistency.ci
      },
      alternatives: {
        names: Array(numAlternatives).fill('').map((_, i) => `Alternative ${i+1}`),
        scores: finalScores,
        weightedScores: alternativesWeightedScores
      }
    };
  }
  
  // Calculate weights from matrix using eigenvalue method
  calculateWeights(matrix: AHPMatrix): number[] {
    const n = matrix.length;
    
    // If matrix is empty or invalid, return empty array
    if (n === 0 || matrix.some(row => row.length !== n)) {
      return [];
    }
    
    // Step 1: Sum each column
    const columnSums = Array(n).fill(0);
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        columnSums[j] += matrix[i][j];
      }
    }
    
    // Step 2: Normalize the matrix by dividing each entry by its column sum
    const normalizedMatrix = matrix.map((row, i) => 
      row.map((cell, j) => cell / columnSums[j])
    );
    
    // Step 3: Calculate the average of each row to get the weights
    const weights = normalizedMatrix.map(row => 
      row.reduce((sum, cell) => sum + cell, 0) / n
    );
    
    return weights;
  }
  
  // Calculate consistency ratio of matrix
  calculateConsistency(matrix: AHPMatrix, weights: number[]): {
    lambdaMax: number;
    ci: number;
    cr: number;
    isConsistent: boolean;
  } {
    const n = matrix.length;
    
    // If matrix is empty or invalid, return default values
    if (n === 0 || matrix.some(row => row.length !== n) || weights.length !== n) {
      return { lambdaMax: 0, ci: 0, cr: 0, isConsistent: true };
    }
    
    // Step 1: Calculate weighted sum vector
    const weightedSum = Array(n).fill(0);
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        weightedSum[i] += matrix[i][j] * weights[j];
      }
    }
    
    // Step 2: Calculate lambda values
    const lambdaValues = weightedSum.map((sum, i) => sum / weights[i]);
    
    // Step 3: Calculate lambda max (average of lambda values)
    const lambdaMax = lambdaValues.reduce((sum, value) => sum + value, 0) / n;
    
    // Step 4: Calculate Consistency Index (CI)
    const ci = (lambdaMax - n) / (n - 1);
    
    // Step 5: Calculate Consistency Ratio (CR) using Random Index (RI)
    const ri = n <= 10 ? RANDOM_CONSISTENCY_INDEX[n] : 1.5;
    const cr = ci / ri;
    
    // A CR value of 0.1 or less is generally considered acceptable
    const isConsistent = cr <= 0.1;
    
    return { lambdaMax, ci, cr, isConsistent };
  }
  
  // Generate PDF report for AHP results
  async generateReport(results: AHPResult, cars: Car[]): Promise<Buffer> {
    // Since we can't use actual PDF libraries here, we'll create an HTML version
    // that would be converted to PDF on the backend
    // In a real implementation, this would use a PDF generation library like pdfkit
    
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>AHP Analysis Report</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; }
          h1 { color: #1d5e91; }
          h2 { color: #2c3e50; margin-top: 20px; }
          table { border-collapse: collapse; width: 100%; margin: 15px 0; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f2f2f2; }
          .winner { background-color: #e6f7e6; }
          .header { display: flex; justify-content: space-between; align-items: center; }
          .logo { font-size: 24px; font-weight: bold; color: #1d5e91; }
          .date { font-size: 14px; color: #666; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo">AutoAHP</div>
          <div class="date">Ngày tạo: ${new Date().toLocaleDateString('vi-VN')}</div>
        </div>
        
        <h1>Báo cáo Phân tích AHP - Lựa chọn ô tô</h1>
        
        <h2>1. Thông tin chung</h2>
        <p>Phân tích này so sánh ${cars.length} mẫu xe dựa trên phương pháp phân tích thứ bậc (AHP).</p>
        
        <h2>2. Các xe được so sánh</h2>
        <table>
          <tr>
            <th>Xe</th>
            <th>Hãng</th>
            <th>Phân khúc</th>
            <th>Giá (VNĐ)</th>
            <th>Công suất (HP)</th>
            <th>Tiêu thụ (L/100km)</th>
          </tr>
          ${cars.map(car => `
            <tr>
              <td>${car.name} ${car.model}</td>
              <td>${car.brand}</td>
              <td>${car.category}</td>
              <td>${new Intl.NumberFormat('vi-VN').format(Number(car.price))}</td>
              <td>${car.horsepower}</td>
              <td>${car.fuelConsumption}</td>
            </tr>
          `).join('')}
        </table>
        
        <h2>3. Trọng số các tiêu chí</h2>
        <table>
          <tr>
            <th>Tiêu chí</th>
            <th>Trọng số</th>
            <th>Phần trăm</th>
          </tr>
          ${results.criteria.names.map((name, i) => `
            <tr>
              <td>${name}</td>
              <td>${results.criteria.weights[i].toFixed(4)}</td>
              <td>${(results.criteria.weights[i] * 100).toFixed(1)}%</td>
            </tr>
          `).join('')}
        </table>
        <p>
          Chỉ số nhất quán (CR): ${results.criteria.consistencyRatio.toFixed(4)} 
          (${results.criteria.consistencyRatio <= 0.1 ? 'Chấp nhận được' : 'Không nhất quán'})
        </p>
        
        <h2>4. Kết quả phân tích</h2>
        <table>
          <tr>
            <th>Hạng</th>
            <th>Xe</th>
            <th>Điểm số</th>
          </tr>
          ${results.alternatives.scores
            .map((score, i) => ({ 
              car: cars[i], 
              score,
              rank: results.alternatives.scores.filter(s => s > score).length + 1 
            }))
            .sort((a, b) => a.rank - b.rank)
            .map(({ car, score, rank }) => `
              <tr class="${rank === 1 ? 'winner' : ''}">
                <td>${rank}</td>
                <td>${car.brand} ${car.name} ${car.model}</td>
                <td>${score.toFixed(4)}</td>
              </tr>
            `).join('')}
        </table>
        
        <h2>5. Kết luận</h2>
        <p>
          Dựa trên các tiêu chí đã cho và phân tích AHP, xe phù hợp nhất là 
          <strong>${
            cars[results.alternatives.scores.indexOf(Math.max(...results.alternatives.scores))].brand
          } ${
            cars[results.alternatives.scores.indexOf(Math.max(...results.alternatives.scores))].name
          } ${
            cars[results.alternatives.scores.indexOf(Math.max(...results.alternatives.scores))].model
          }</strong> 
          với điểm số ${Math.max(...results.alternatives.scores).toFixed(4)}.
        </p>
        
        <div style="margin-top: 40px; text-align: center; font-size: 12px; color: #666;">
          <p>Báo cáo này được tạo tự động bởi AutoAHP - Hệ thống hỗ trợ ra quyết định mua ô tô</p>
        </div>
      </body>
      </html>
    `;
    
    // In a real implementation, we would convert HTML to PDF here
    // For now, we'll just return the HTML as a buffer
    return Buffer.from(htmlContent);
  }
}

export const ahpCalculator = new AHPCalculatorImplementation();
