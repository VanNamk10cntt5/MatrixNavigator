import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ahpCalculator } from "./ahpCalculator";
import { ahpMatrixSchema, ahpResultSchema } from "@shared/schema";
import * as fs from 'fs';
import path from 'path';
import axios from 'axios';
import { spawn } from 'child_process';

// Khởi động Flask API service
let flaskProcess: any = null;
let flaskApiReady = false;
const FLASK_API_PORT = 5001;
const FLASK_API_BASE_URL = `http://localhost:${FLASK_API_PORT}/api`;

function startFlaskApi() {
  console.log('[express] Starting Flask AHP API service...');
  
  // Khởi động Python API
  flaskProcess = spawn('python', ['python_api/app.py'], {
    stdio: ['ignore', 'pipe', 'pipe'],
    env: { ...process.env, PYTHONUNBUFFERED: '1' }
  });
  
  flaskProcess.stdout.on('data', (data: Buffer) => {
    console.log(`[flask] ${data.toString().trim()}`);
    
    // Kiểm tra khi Flask API đã sẵn sàng
    if (data.toString().includes('Running on http://')) {
      flaskApiReady = true;
      console.log('[express] Flask AHP API service is ready');
    }
  });
  
  flaskProcess.stderr.on('data', (data: Buffer) => {
    console.error(`[flask-error] ${data.toString().trim()}`);
  });
  
  flaskProcess.on('close', (code: number) => {
    console.log(`[express] Flask AHP API process exited with code ${code}`);
    flaskApiReady = false;
    
    // Thử khởi động lại sau 5 giây nếu Flask bị đóng
    setTimeout(() => {
      if (!flaskProcess || flaskProcess.exitCode !== null) {
        startFlaskApi();
      }
    }, 5000);
  });
  
  // Đảm bảo đóng Flask khi ứng dụng Node tắt
  process.on('exit', () => {
    if (flaskProcess && flaskProcess.exitCode === null) {
      flaskProcess.kill();
    }
  });
}

// Check Flask API health
async function checkFlaskApiHealth(): Promise<boolean> {
  try {
    const response = await axios.get(`${FLASK_API_BASE_URL}/health`);
    return response.status === 200 && response.data.status === 'healthy';
  } catch (error) {
    return false;
  }
}

// Proxy route để gọi đến Flask API
function proxyToFlaskApi(path: string) {
  return async (req: Request, res: Response) => {
    try {
      if (!flaskApiReady) {
        // Thử kiểm tra trạng thái API trước khi trả về lỗi
        const isHealthy = await checkFlaskApiHealth();
        if (!isHealthy) {
          console.log('[express] Flask API không sẵn sàng, đang thử khởi động lại...');
          return res.status(503).json({ error: 'AHP Calculation service is starting. Please try again in a few seconds.' });
        }
      }
      
      const flaskApiUrl = `${FLASK_API_BASE_URL}/${path}`;
      console.log(`[express] Proxying request to Flask API: ${flaskApiUrl}`);
      
      // Chuyển tiếp request đến Flask API
      const response = await axios({
        method: req.method,
        url: flaskApiUrl,
        data: req.body,
        headers: {
          'Content-Type': 'application/json',
        },
        responseType: path === 'generate-report' ? 'arraybuffer' : 'json',
      });
      
      // Thiết lập headers cho response
      if (path === 'generate-report') {
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename=AHP_Analysis_Report.pdf');
        res.send(Buffer.from(response.data));
      } else {
        res.json(response.data);
      }
    } catch (error: any) {
      console.error(`[express] Error proxying to Flask API: ${error.message}`);
      
      if (error.response) {
        // Lỗi được trả về từ Flask API
        const status = error.response.status || 500;
        const errorData = error.response.data;
        res.status(status).json(typeof errorData === 'object' ? errorData : { error: String(errorData) });
      } else {
        // Lỗi kết nối hoặc lỗi khác
        res.status(500).json({ error: `Failed to reach AHP calculation service: ${error.message}` });
      }
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Khởi động Flask API
  startFlaskApi();
  // Get all cars (with optional filters)
  app.get('/api/cars', async (req, res) => {
    try {
      const {
        category,
        priceMax,
        brand,
        horsepowerMin,
        fuelConsumptionMax,
        sort
      } = req.query;

      const filters: any = {};
      
      // Apply filters if they exist
      if (category) filters.category = category;
      if (brand) filters.brand = brand;
      if (priceMax) filters.priceMax = Number(priceMax);
      if (horsepowerMin) filters.horsepowerMin = Number(horsepowerMin);
      if (fuelConsumptionMax) filters.fuelConsumptionMax = Number(fuelConsumptionMax);

      const cars = await storage.getCars(filters);
      
      // Apply sorting
      let sortedCars = [...cars];
      
      if (sort) {
        switch (sort) {
          case 'price-asc':
            sortedCars.sort((a, b) => Number(a.price) - Number(b.price));
            break;
          case 'price-desc':
            sortedCars.sort((a, b) => Number(b.price) - Number(a.price));
            break;
          case 'power-desc':
            sortedCars.sort((a, b) => b.horsepower - a.horsepower);
            break;
          case 'fuel-asc':
            sortedCars.sort((a, b) => Number(a.fuelConsumption) - Number(b.fuelConsumption));
            break;
          default:
            break;
        }
      }

      res.json(sortedCars);
    } catch (error) {
      console.error('Error fetching cars:', error);
      res.status(500).json({ error: 'Failed to fetch cars' });
    }
  });

  // Get car by ID
  app.get('/api/cars/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid car ID' });
      }

      const car = await storage.getCarById(id);
      if (!car) {
        return res.status(404).json({ error: 'Car not found' });
      }

      res.json(car);
    } catch (error) {
      console.error('Error fetching car:', error);
      res.status(500).json({ error: 'Failed to fetch car' });
    }
  });

  // Calculate AHP - sử dụng Flask API cho tính toán
  app.post('/api/ahp/calculate', async (req, res) => {
    try {
      const { criteriaMatrix, alternativeMatrices, alternatives } = req.body;
      
      // Validate input data
      if (!criteriaMatrix || !alternativeMatrices || !alternatives) {
        return res.status(400).json({ error: 'Missing required data for AHP calculation' });
      }
      
      // Validate matrices with schema
      try {
        ahpMatrixSchema.parse(criteriaMatrix);
        Object.values(alternativeMatrices).forEach(matrix => {
          ahpMatrixSchema.parse(matrix);
        });
      } catch (error) {
        return res.status(400).json({ error: 'Invalid matrix format', details: error });
      }
      
      // Get car details for the alternatives
      const cars = await Promise.all(
        alternatives.map(async (id: string) => await storage.getCarById(parseInt(id)))
      );
      
      if (cars.some(car => !car)) {
        return res.status(400).json({ error: 'One or more cars not found' });
      }
      
      // Use either JavaScript or Python implementation based on availability
      try {
        if (await checkFlaskApiHealth()) {
          // Sử dụng Flask API
          const response = await axios({
            method: 'post',
            url: `${FLASK_API_BASE_URL}/calculate`,
            data: { criteriaMatrix, alternativeMatrices },
            headers: { 'Content-Type': 'application/json' }
          });
          
          console.log('[express] Used Python implementation for AHP calculation');
          res.json(response.data);
        } else {
          // Fallback to JavaScript implementation
          console.log('[express] Falling back to JavaScript implementation for AHP calculation');
          const results = ahpCalculator.calculateAHP(criteriaMatrix, alternativeMatrices);
          res.json(results);
        }
      } catch (apiError) {
        // Fallback to JavaScript implementation on API error
        console.log('[express] API error, using JavaScript implementation', apiError);
        const results = ahpCalculator.calculateAHP(criteriaMatrix, alternativeMatrices);
        res.json(results);
      }
    } catch (error) {
      console.error('Error calculating AHP:', error);
      res.status(500).json({ error: 'Failed to calculate AHP results' });
    }
  });

  // Generate AHP report PDF - sử dụng Flask API
  app.post('/api/ahp/report', proxyToFlaskApi('generate-report'));

  // Initialize sample data on server start
  await storage.initializeSampleData();

  const httpServer = createServer(app);
  return httpServer;
}
