import { pgTable, text, serial, integer, numeric, boolean, array } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Car categories
export const carCategories = [
  "Sedan",
  "SUV",
  "Hatchback",
  "Pickup",
  "Crossover",
  "MPV"
] as const;

export const cars = pgTable("cars", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  model: text("model").notNull(),
  brand: text("brand").notNull(),
  category: text("category").notNull(),
  price: numeric("price").notNull(),
  horsepower: integer("horsepower").notNull(),
  fuelConsumption: numeric("fuel_consumption").notNull(),
  airbags: integer("airbags").notNull(),
  safetyRating: integer("safety_rating").notNull(),
  features: text("features").array(),
  imageUrl: text("image_url").notNull(),
});

export const insertCarSchema = createInsertSchema(cars).omit({
  id: true
});

export type InsertCar = z.infer<typeof insertCarSchema>;
export type Car = typeof cars.$inferSelect;

// AHP Criteria
export const ahpCriteria = [
  "price",
  "horsepower",
  "fuelConsumption",
  "safety",
  "comfort",
  "brand"
] as const;

// AHP Matrix for criteria comparisons
export type AHPMatrix = number[][];

// AHP Results
export type AHPResult = {
  criteria: {
    names: string[];
    weights: number[];
    consistencyRatio: number;
    lambdaMax: number;
    consistencyIndex: number;
  };
  alternatives: {
    names: string[];
    scores: number[];
    weightedScores: { [key: string]: number[] };
  };
};

export const ahpMatrixSchema = z.array(z.array(z.number()));
export const ahpResultSchema = z.object({
  criteria: z.object({
    names: z.array(z.string()),
    weights: z.array(z.number()),
    consistencyRatio: z.number(),
    lambdaMax: z.number(),
    consistencyIndex: z.number(),
  }),
  alternatives: z.object({
    names: z.array(z.string()),
    scores: z.array(z.number()),
    weightedScores: z.record(z.array(z.number())),
  }),
});
